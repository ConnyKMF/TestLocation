//
//  EHSearchTagListView.m
//  KMFSeatchViewDemo
//
//  Created by 岳琛 on 2017/11/3.
//  Copyright © 2017年 KMF-Engineering. All rights reserved.
//

#import "EHSearchTagListView.h"
#import "EHSearchTagListCell.h"
#import "EHSearchTagListReusableView.h"

@interface EHSearchTagListView () <UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>


@property (nonatomic,strong)UICollectionViewFlowLayout *flowLayout;

@property (nonatomic,strong)UICollectionView *bomttomcollectionView;

@property (nonatomic,strong)NSMutableArray *contentArr;

@property (nonatomic,assign)BOOL isLongPress;

@property (nonatomic,assign)CGSize size;

@end

@implementation EHSearchTagListView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self configSubviews];
    }
    return self;
}

- (NSMutableArray *)contentArr
{
    if (!_contentArr) {
        _contentArr = @[].mutableCopy;
    }
    return _contentArr;
}

- (void)configSubviews
{
    self.backgroundColor = [UIColor colorWithRed:241/255.0 green:241/255.0 blue:241/255.0 alpha:1.0];
    
    self.flowLayout = [[UICollectionViewFlowLayout alloc]init];
    self.bomttomcollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height) collectionViewLayout:_flowLayout];
    _bomttomcollectionView.delegate = self;
    _bomttomcollectionView.dataSource = self;
    _bomttomcollectionView.backgroundColor = [UIColor clearColor];
    [_bomttomcollectionView registerNib:[UINib nibWithNibName:@"EHSearchTagListCell" bundle:nil] forCellWithReuseIdentifier:@"EHSearchTagListCell"];
    [_bomttomcollectionView registerClass:[EHSearchTagListReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"mineHeader"];
    [self addSubview:_bomttomcollectionView];
}

#pragma mark -
#pragma mark CollectionView Delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.contentArr.count;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (_isLongPress)
        [self startCellTouchMethodWhenGestureLongPress:indexPath];
    else
        [self startCellTouchMethodWhenGestureTap:indexPath];
}

#pragma mark CollectionView Datasource
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    EHSearchTagListCell *tagcell = [collectionView dequeueReusableCellWithReuseIdentifier:@"EHSearchTagListCell" forIndexPath:indexPath];
    tagcell.layer.cornerRadius = 2.f;
    tagcell.layer.masksToBounds = YES;
    tagcell.backgroundColor = [UIColor colorWithRed:105/255.0 green:210/255.0 blue:206/255.0 alpha:1.0];
    tagcell.textLbl.text = self.contentArr[indexPath.row];
    tagcell.textLbl.textColor = [UIColor whiteColor];
    tagcell.textLbl.textAlignment = NSTextAlignmentCenter;
    
    [tagcell.deleteSymbloView setHidden:!_isLongPress];
    
    UILongPressGestureRecognizer *longPressGes = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPress:)];
    longPressGes.minimumPressDuration = 1;
    [tagcell addGestureRecognizer:longPressGes];
    
    return tagcell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    _size = [_contentArr[indexPath.row] sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:18]}];
    return CGSizeMake(_size.width,25);
}


- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(5, 5, 5, 5);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(self.frame.size.width, 44.0);
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if([kind isEqualToString:UICollectionElementKindSectionHeader])
    {
        EHSearchTagListReusableView * reusableView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"mineHeader" forIndexPath:indexPath];
        reusableView.titleLbl.text = @"#热门活动#";
        reusableView.backgroundColor = [UIColor colorWithRed:241/255.0 green:241/255.0 blue:241/255.0 alpha:1.0];
        return reusableView;
    }
    
    return nil;
}

#pragma mark - Action
- (void)startCellTouchMethodWhenGestureLongPress:(NSIndexPath *)indexPath
{
    [UIView animateWithDuration:0.25 animations:^{
        [self.contentArr removeObjectAtIndex:indexPath.row];
        [self.bomttomcollectionView deleteItemsAtIndexPaths:@[indexPath]];
    } completion:^(BOOL finished) {
        NSLog(@"startCellTouchMethodWhenGestureLongPress");
    }];
}

- (void)startCellTouchMethodWhenGestureTap:(NSIndexPath *)indexPath
{
    NSLog(@"startCellTouchMethodWhenGestureTap");
}

#pragma mark - GestureRecognizer Delegate
-(void)longPress:(UIGestureRecognizer *)sender
{
    _isLongPress = YES;
    [_bomttomcollectionView reloadData];
}

#pragma mark - Public Methods
- (void)setTagListModel:(NSArray *)array
{
    if (array.count < 1) return;
    
    self.contentArr = array.mutableCopy;
    [self.bomttomcollectionView reloadData];
}

@end
