//
//  main.m
//  KMFSeatchViewDemo
//
//  Created by 岳琛 on 2017/11/3.
//  Copyright © 2017年 KMF-Engineering. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
