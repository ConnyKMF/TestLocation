//
//  ViewController.m
//  KMFSeatchViewDemo
//
//  Created by 岳琛 on 2017/11/3.
//  Copyright © 2017年 KMF-Engineering. All rights reserved.
//

#import "ViewController.h"
#import "EHSearchTagListView.h"

@interface ViewController ()

@property (strong, nonatomic) NSMutableArray *dataList;
@property (strong, nonatomic) EHSearchTagListView *sTagListView;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view addSubview:self.sTagListView];
    [self.sTagListView setTagListModel:@[@"123123123",@"111",@"2",@"3",@"43",@"123123123123123",@"11111",@"222",@"33",@"4"]];
}

- (EHSearchTagListView *)sTagListView
{
    if (!_sTagListView) {
        _sTagListView = [[EHSearchTagListView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width-100, self.view.frame.size.height-100)];
        _sTagListView.center = self.view.center;
    }
    return _sTagListView;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


@end
