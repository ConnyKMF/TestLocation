//
//  EHSearchTagListReusableView.m
//  KMFSeatchViewDemo
//
//  Created by 岳琛 on 2017/11/3.
//  Copyright © 2017年 KMF-Engineering. All rights reserved.
//

#import "EHSearchTagListReusableView.h"

@implementation EHSearchTagListReusableView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.titleLbl];
    }
    return self;
}

- (UILabel *)titleLbl
{
    if (!_titleLbl) {
        _titleLbl = [[UILabel alloc] initWithFrame:CGRectMake(16, 0, self.frame.size.width - 38, self.frame.size.height)];
        _titleLbl.font = [UIFont systemFontOfSize:16];
        _titleLbl.textAlignment = NSTextAlignmentLeft;
        _titleLbl.textColor = [UIColor blackColor];
    }
    return _titleLbl;
}

@end
